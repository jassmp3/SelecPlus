(() => {
  'use strict';
  if (window.__selecPlusLoaded) return;
  window.__selecPlusLoaded = true;

  // ---------- state ----------
  let enabled = true;
  let dragging = false;
  let sx = 0, sy = 0, cx = 0, cy = 0;
  let box = null, styleEl = null;
  let swallowUntil = 0;

  try {
    chrome.storage.local.get({ enabled: true }, (r) => { enabled = r.enabled !== false; });
    chrome.storage.onChanged.addListener((c, area) => {
      if (area === 'local' && c.enabled) {
        enabled = c.enabled.newValue !== false;
        if (!enabled) cancel();
      }
    });
  } catch (_) { /* extension context gone */ }

  const IS_MAC = /Mac|iPhone|iPad/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');
  const hasMod = (e) => (IS_MAC ? e.metaKey : e.ctrlKey);

  const STRONG = [
    'input[type=checkbox]', 'input[type=radio]', 'input[type=button]', 'input[type=submit]', 'input[type=reset]',
    'button', 'summary', 'a[href]',
    '[role=checkbox]', '[role=radio]', '[role=button]', '[role=switch]', '[role=menuitemcheckbox]',
    '[role=menuitemradio]', '[role=option]', '[role=tab]', '[role=link]', '[aria-checked]', '[aria-pressed]'
  ].join(',');
  const WEAK = 'label,[data-seat],[data-seat-id],[data-seatid],[class*="seat" i],[onclick]';

  // ---------- helpers ----------
  const block = (e) => { e.preventDefault(); e.stopImmediatePropagation(); };
  const parentOf = (el) => {
    if (el.parentElement) return el.parentElement;
    const root = el.getRootNode && el.getRootNode();
    return root && root.host ? root.host : null;
  };

  function injectStyle() {
    styleEl = document.createElement('style');
    styleEl.textContent =
      'html, html * { -webkit-user-select: none !important; user-select: none !important; -webkit-user-drag: none !important; }';
    (document.head || document.documentElement).appendChild(styleEl);
  }
  function removeStyle() { if (styleEl) { styleEl.remove(); styleEl = null; } }

  function makeBox() {
    box = document.createElement('div');
    box.setAttribute('data-selec-plus', '');
    box.style.cssText = [
      'position:fixed', 'z-index:2147483647', 'pointer-events:none', 'box-sizing:border-box',
      'left:0', 'top:0', 'width:0', 'height:0', 'margin:0', 'padding:0',
      'border:1.5px solid #00f0ff', 'border-radius:3px',
      'background:rgba(0,240,255,.10)',
      'box-shadow:0 0 4px #00f0ff,0 0 14px rgba(0,240,255,.75),0 0 30px rgba(0,240,255,.35),inset 0 0 14px rgba(0,240,255,.35)',
      'opacity:1', 'transition:opacity .16s ease'
    ].map((s) => s + ' !important').join(';');
    document.documentElement.appendChild(box);
  }
  function draw() {
    if (!box) return;
    const s = box.style;
    s.setProperty('left', Math.min(sx, cx) + 'px', 'important');
    s.setProperty('top', Math.min(sy, cy) + 'px', 'important');
    s.setProperty('width', Math.abs(cx - sx) + 'px', 'important');
    s.setProperty('height', Math.abs(cy - sy) + 'px', 'important');
  }
  function fadeBox() {
    const b = box; box = null;
    if (!b) return;
    b.style.setProperty('opacity', '0', 'important');
    setTimeout(() => b.remove(), 200);
  }

  function cancel() {
    if (!dragging) return;
    dragging = false;
    fadeBox();
    removeStyle();
  }

  // ---------- event wiring ----------
  function onDown(e) {
    if (!e.isTrusted) return;
    if (dragging) { block(e); return; }
    if (!enabled || e.button !== 0 || !hasMod(e)) return;
    block(e);
    dragging = true;
    sx = cx = e.clientX;
    sy = cy = e.clientY;
    try { document.getSelection().removeAllRanges(); } catch (_) {}
    injectStyle();
    makeBox();
    draw();
  }
  function onMove(e) {
    if (!dragging || !e.isTrusted) return;
    block(e);
    if (e.buttons === 0) { finish(); return; } // button released somewhere we couldn't see
    cx = e.clientX; cy = e.clientY;
    draw();
  }
  function onUp(e) {
    if (!e.isTrusted) return;
    if (dragging) {
      block(e);
      if (e.button === 0) { cx = e.clientX; cy = e.clientY; finish(); }
      return;
    }
    if (Date.now() < swallowUntil) block(e);
  }
  function onClick(e) { if (e.isTrusted && Date.now() < swallowUntil) block(e); }
  function onGuard(e) { if (dragging || Date.now() < swallowUntil) block(e); }
  function onKey(e) { if (dragging && e.key === 'Escape') { block(e); cancel(); } }

  const opts = { capture: true, passive: false };
  ['pointerdown', 'mousedown'].forEach((t) => window.addEventListener(t, onDown, opts));
  ['pointermove', 'mousemove'].forEach((t) => window.addEventListener(t, onMove, opts));
  ['pointerup', 'mouseup'].forEach((t) => window.addEventListener(t, onUp, opts));
  window.addEventListener('click', onClick, opts);
  ['contextmenu', 'dragstart', 'selectstart', 'dragenter', 'dragover'].forEach((t) => window.addEventListener(t, onGuard, opts));
  window.addEventListener('keydown', onKey, opts);
  window.addEventListener('blur', cancel);

  // ---------- selection ----------
  function finish() {
    const rect = { l: Math.min(sx, cx), t: Math.min(sy, cy), r: Math.max(sx, cx), b: Math.max(sy, cy) };
    dragging = false;
    swallowUntil = Date.now() + 150;
    fadeBox();
    removeStyle(); // must go before scanning so computed cursors are the page's own
    selectIn(rect);
  }

  function* walk(root) {
    for (const el of root.querySelectorAll('*')) {
      yield el;
      if (el.shadowRoot) yield* walk(el.shadowRoot);
    }
  }

  function collect(sel) {
    const strongSet = new Set();
    const all = new Set();
    const vw = window.innerWidth, vh = window.innerHeight;

    for (const el of walk(document)) {
      if (el.hasAttribute('data-selec-plus')) continue;
      const rc = el.getBoundingClientRect();
      if (rc.width <= 0 || rc.height <= 0) continue;
      if (rc.right < sel.l - 1 || rc.left > sel.r + 1 || rc.bottom < sel.t - 1 || rc.top > sel.b + 1) continue;
      const tag = el.tagName;
      if (tag === 'HTML' || tag === 'BODY') continue;

      const cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.pointerEvents === 'none') continue;

      const strong = el.matches(STRONG);
      let weak = !strong && el.matches(WEAK);
      if (!strong && !weak) {
        if (cs.cursor !== 'pointer') continue;
        const p = parentOf(el);
        if (p && getComputedStyle(p).cursor === 'pointer') continue; // inner part of a clickable region
        weak = true;
      }
      if (!strong && rc.width * rc.height > vw * vh * 0.25) continue; // big wrappers aren't targets

      all.add(el);
      if (strong) strongSet.add(el);
    }

    const list = [...all];
    // weak containers that hold other targets are just wrappers
    const hasDesc = new Set();
    for (const el of list) { let p = parentOf(el); while (p) { hasDesc.add(p); p = parentOf(p); } }
    let kept = list.filter((el) => strongSet.has(el) || !hasDesc.has(el));
    const keptSet = new Set(kept);
    // a label whose input is already targeted, and parts nested inside a real control
    kept = kept.filter((el) => {
      if (el.tagName === 'LABEL' && el.control && keptSet.has(el.control)) return false;
      let p = parentOf(el);
      while (p) { if (keptSet.has(p) && strongSet.has(p)) return false; p = parentOf(p); }
      return true;
    });

    const rects = new Map(kept.map((el) => [el, el.getBoundingClientRect()]));
    kept.sort((a, b) => {
      const ra = rects.get(a), rb = rects.get(b);
      return (ra.top - rb.top) || (ra.left - rb.left);
    });
    return { kept, rects };
  }

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const isLink = (el) => el.tagName === 'A' && el.hasAttribute('href');

  async function selectIn(sel) {
    let found;
    try { found = collect(sel); } catch (_) { return; }
    const { kept, rects } = found;
    const multiLink = kept.filter(isLink).length > 1;
    for (const el of kept) {
      if (!el.isConnected) continue;
      const rc = rects.get(el);
      const x = (Math.max(rc.left, sel.l) + Math.min(rc.right, sel.r)) / 2;
      const y = (Math.max(rc.top, sel.t) + Math.min(rc.bottom, sel.b)) / 2;
      try { activate(el, x, y, multiLink); } catch (_) {}
      await wait(10);
    }
  }

  function activate(el, x, y, multiLink) {
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return;
    const tag = el.tagName;
    if (tag === 'INPUT' && (el.type === 'checkbox' || el.type === 'radio') && el.checked) return;
    if (el.getAttribute('aria-checked') === 'true') return;
    if (el.getAttribute('aria-pressed') === 'true') return;
    if (el.getAttribute('aria-selected') === 'true') return;
    if (tag === 'SUMMARY' && el.parentElement && el.parentElement.open) return;

    const mods = {};
    if (multiLink && isLink(el)) { // several links: open in background tabs instead of navigating away
      if (IS_MAC) mods.metaKey = true; else mods.ctrlKey = true;
    }
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, ...mods };
    const P = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    const ptr = { pointerId: 1, pointerType: 'mouse', isPrimary: true };
    el.dispatchEvent(new P('pointerdown', { ...base, ...ptr, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
    el.dispatchEvent(new P('pointerup', { ...base, ...ptr, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0, detail: 1 }));
  }
})();
