(() => {
  'use strict';

  // ---------- global on/off ----------
  const power = document.getElementById('power');
  chrome.storage.local.get({ enabled: true }, (r) => { power.checked = r.enabled !== false; });
  power.addEventListener('change', () => chrome.storage.local.set({ enabled: power.checked }));

  // ---------- blob (white sphere: only the eyes move) ----------
  const $ = (id) => document.getElementById(id);
  const pet = $('pet');
  const svg = $('blob');
  const rand = (a, b) => a + Math.random() * (b - a);
  const shuffle = (arr) => { for (let i = arr.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };

  const KEYS = ['w', 'h', 'rot', 'c', 'slope', 'arc', 'dx', 'dy'];
  const NEUTRAL = { w: 20, h: 46, rot: -10, c: 0, slope: 0, arc: 0, dx: 0, dy: 0 };
  // eye shape per expression; s = -1 left eye, +1 right eye
  const SHAPES = {
    happy:    (s) => ({ ...NEUTRAL, w: 22, h: 50, rot: -12 }),
    shy:      (s) => ({ w: 18, h: 32, rot: -s * 16, c: 0, slope: 0, arc: 0, dx: -s * 4, dy: 9 }),
    angry:    (s) => ({ w: 21, h: 44, rot: s * 8, c: 0.3, slope: -s * 0.55, arc: 0, dx: s, dy: -2 }),
    sleepy:   (s) => ({ w: 22, h: 40, rot: -s * 5, c: 0.55, slope: 0, arc: 0, dx: 0, dy: 7 }),
    joy:      (s) => ({ ...NEUTRAL, rot: 0, arc: 1, dy: -2 }),
    surprise: (s) => ({ w: 25, h: 64, rot: 0, c: 0, slope: 0, arc: 0, dx: s * 3, dy: -4 }),
    cross:    (s) => ({ ...NEUTRAL, rot: 0, dx: -s * 15, dy: 3 }),
    yawn:     (s) => ({ w: 22, h: 40, rot: 0, c: 0.85, slope: 0, arc: 0, dx: 0, dy: 8 })
  };

  const eyes = ['L', 'R'].map((k, i) => ({
    s: i ? 1 : -1,
    g: $('eye' + k), pill: $('pill' + k), arc: $('arc' + k), cut: $('cut' + k),
    st: { ...NEUTRAL, w: 22, h: 50, rot: -12, bm: 1 },
    blinkTarget: 1
  }));

  // expression cycle (slow) + temporary click reactions
  const CYCLE = ['happy', 'shy', 'angry', 'sleepy'];
  let cycleIdx = 0, mode = null, modeTimer = null;
  setInterval(() => { cycleIdx = (cycleIdx + 1) % CYCLE.length; }, 7000);
  const current = () => mode || CYCLE[cycleIdx];
  function setMode(name, ms) {
    mode = name;
    clearTimeout(modeTimer);
    modeTimer = setTimeout(() => { mode = null; }, ms);
  }

  // blinking every 3–4 s
  function blinkOnce(cb) {
    eyes.forEach((e) => { e.blinkTarget = 0.08; });
    setTimeout(() => { eyes.forEach((e) => { e.blinkTarget = 1; }); if (cb) cb(); }, 140);
  }
  (function scheduleBlink() { setTimeout(() => { blinkOnce(); scheduleBlink(); }, rand(3000, 4000)); })();

  // gaze: follows the cursor while it is over the popup, wanders when it isn't
  const look = { x: 0, y: 0 };
  const mouse = { x: 0, y: 0, follow: false };
  const DIRS = { straight: [0, 0], left: [-0.85, 0], right: [0.85, 0], up: [0, -0.8], down: [0, 0.8] };
  let wander = [0, 0], bag = [];
  function wanderStep() {
    if (!bag.length) bag = shuffle(['straight', 'left', 'right', 'up', 'down', 'straight']);
    wander = DIRS[bag.pop()];
  }
  wanderStep();
  setInterval(wanderStep, 2400);
  document.addEventListener('mousemove', (e) => { mouse.x = e.clientX; mouse.y = e.clientY; mouse.follow = true; });
  document.documentElement.addEventListener('mouseleave', () => { mouse.follow = false; });

  function gazeTarget() {
    if (!mouse.follow) return wander;
    const r = svg.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + (r.height * 96) / 200;
    const dx = mouse.x - cx, dy = mouse.y - cy;
    const dist = Math.hypot(dx, dy) || 1;
    const mag = Math.min(1, dist / 110);
    return [(dx / dist) * mag, (dy / dist) * mag];
  }

  // click = a different eye-only reaction each time (the ball itself never moves)
  const reactions = [
    () => setMode('joy', 1500),
    () => setMode('surprise', 1100),
    () => { setMode('happy', 900); eyes[1].blinkTarget = 0.08; setTimeout(() => { eyes[1].blinkTarget = 1; }, 550); }, // wink
    () => blinkOnce(() => setTimeout(() => blinkOnce(), 120)),                                                    // double blink
    () => setMode('cross', 1200),
    () => setMode('yawn', 1600)
  ];
  let rbag = [], lastR = -1;
  pet.addEventListener('click', () => {
    if (!rbag.length) { rbag = shuffle(reactions.map((_, i) => i)); if (rbag[rbag.length - 1] === lastR) rbag.reverse(); }
    lastR = rbag.pop();
    reactions[lastR]();
  });

  // render loop
  const BASE_X = 32, BASE_Y = -2, FACE_R = 98;
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(60, now - last); last = now;
    const kLook = 1 - Math.exp(-dt / 240);
    const kShape = 1 - Math.exp(-dt / 200);
    const kBlink = 1 - Math.exp(-dt / 45);

    const [tx, ty] = gazeTarget();
    look.x += (tx - look.x) * kLook;
    look.y += (ty - look.y) * kLook;
    const shapeFor = SHAPES[current()];

    for (const e of eyes) {
      const t = shapeFor(e.s), st = e.st;
      for (const k of KEYS) st[k] += (t[k] - st[k]) * kShape;
      st.bm += (e.blinkTarget - st.bm) * kBlink;

      // position on the sphere, squeezed toward the rim so it reads as 3D
      const px = e.s * BASE_X + st.dx + look.x * 36;
      const py = BASE_Y + st.dy + look.y * 32;
      const d = Math.hypot(px, py);
      const n = Math.min(d / FACE_R, 0.93);
      const cs = Math.sqrt(1 - n * n);
      const ang = (Math.atan2(py, px) * 180) / Math.PI;
      e.g.setAttribute('transform',
        `translate(${px.toFixed(2)} ${py.toFixed(2)}) rotate(${ang.toFixed(1)}) scale(${cs.toFixed(3)} 1) rotate(${(-ang).toFixed(1)}) rotate(${(st.rot + px * 0.12).toFixed(1)}) scale(1 ${st.bm.toFixed(3)})`);

      e.pill.setAttribute('x', (-st.w / 2).toFixed(2));
      e.pill.setAttribute('y', (-st.h / 2).toFixed(2));
      e.pill.setAttribute('width', st.w.toFixed(2));
      e.pill.setAttribute('height', st.h.toFixed(2));
      e.pill.setAttribute('rx', (st.w / 2).toFixed(2));
      e.pill.setAttribute('opacity', (1 - st.arc).toFixed(3));
      e.arc.setAttribute('opacity', st.arc.toFixed(3));

      const y0 = -st.h / 2 - 3 + st.c * (st.h + 3);
      e.cut.setAttribute('points',
        `-70,${(y0 - 70 * st.slope).toFixed(2)} 70,${(y0 + 70 * st.slope).toFixed(2)} 70,90 -70,90`);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // ---------- rotating note ----------
  const NOTES = [
    'sudo make me a sandwich. permission denied.',
    'works on my machine. ship the machine.',
    '404: motivation not found.',
    'have you tried turning it off and on again?',
    'ctrl+z cannot undo your decisions. i tried.',
    'compiling... just kidding, this is javascript.',
    'no bugs were harmed. several were promoted to features.',
    'cache cleared. feelings not.',
    'loading personality.exe... 3% complete.',
    'git commit -m "fixed stuff". future me is confused.',
    'i put the "pro" in procrastinate.',
    'there are 10 kinds of people: binary and blob.',
    'ai took my job. blob took the credit.',
    'running on 100% organic, free-range electrons.',
    'semicolons; because; i; can;',
    'localhost is where the heart is. 127.0.0.1.',
    'this note self-destructs in 60 seconds. (it won\'t.)',
    'undefined is not a function. neither am i.',
    'buffering... please blink twice.',
    'zero dependencies, infinite vibes.'
  ];
  const noteEl = document.getElementById('note');
  let nBag = [];
  function nextNote(first) {
    if (!nBag.length) nBag = shuffle(NOTES.map((_, i) => i));
    const text = NOTES[nBag.pop()];
    if (first) { noteEl.textContent = text; return; }
    noteEl.classList.add('fade');
    setTimeout(() => { noteEl.textContent = text; noteEl.classList.remove('fade'); }, 500);
  }
  nextNote(true);
  setInterval(() => nextNote(false), 60000);
})();
